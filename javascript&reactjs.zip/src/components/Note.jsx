import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>JAVA SCRIPT AND REACTJS</h1>
      <p>
    Iam Daravath Bhavani from kasturba gandhi degree and pg college for women
    because of the lockdown we were unable to learn most the
    things from acdemics where shape ai made it go easy 
       </p>
    </div>
  );
}
export default Note;
